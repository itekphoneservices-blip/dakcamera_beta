from datetime import datetime, timedelta

MAX_USERS = 20
DAYS_LIMIT = 7
START_DATE = datetime(2026, 2, 18)